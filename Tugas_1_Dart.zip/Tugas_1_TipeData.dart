void main() {
  // Deklarasi variabel dengan tipe data yang berbeda
  int umur = 23;
  double tinggi = 1.75;
  String nama = 'Arya Daiva M';
  bool isMahasiswa = true;

  // Mencetak nilai variabel
  print('Umur: $umur');
  print('Tinggi: $tinggi');
  print('Nama: $nama');
  print('Is Mahasiswa: $isMahasiswa');
}
