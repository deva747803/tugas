int jumlah(int a, int b) {
  return a + b;
}

void main() {
  int hasil = jumlah(530, 190);
  print('Hasil penjumlahan: $hasil');
}
