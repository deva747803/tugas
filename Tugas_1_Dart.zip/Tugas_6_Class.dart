class Book {
  String title;
  String author;
  double price;

  Book(this.title, this.author, this.price);

  void displayInfo() {
    print("Title: $title");
    print("Author: $author");
    print("Price: \$${price.toStringAsFixed(2)}");
  }

  void applyDiscount(double discountPercentage) {
    price -= price * (discountPercentage / 100);
  }
}

void main() {
  Book book = Book("Dart Programming", "Arya Daiva", 90.99);
  
  book.displayInfo();
  book.applyDiscount(10); // Menerapkan diskon 10%
  print("Harga setelah diskon:");
  book.displayInfo();
}
