import 'dart:io';

void main() {
  int tinggi = 5; // tinggi segitiga
  for (int i = 1; i <= tinggi; i++) {
    for (int j = 1; j <= i; j++) {
      stdout.write("* "); // Menggunakan stdout.write untuk tidak menambah baris baru
    }
    print(""); // Pindah ke baris berikutnya
  }
}
